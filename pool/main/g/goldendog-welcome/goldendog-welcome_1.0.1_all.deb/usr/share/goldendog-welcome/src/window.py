import gi

gi.require_version('Gtk', '4.0')
gi.require_version('Adw', '1')

from gi.repository import Gtk, Adw, Gdk
import os
import gettext
import locale
import json
import urllib.request
import threading

# Setup i18n
# We look for the 'locale' directory in system path first, then relative
SYSTEM_LOCALE_DIR = "/usr/share/locale"
LOCAL_LOCALE_DIR = os.path.join(os.path.dirname(__file__), "..", "locale")

if os.path.exists(os.path.join(SYSTEM_LOCALE_DIR, "es", "LC_MESSAGES", "goldendog-welcome.mo")):
    LOCALE_DIR = SYSTEM_LOCALE_DIR
else:
    LOCALE_DIR = LOCAL_LOCALE_DIR

gettext.bindtextdomain('goldendog-welcome', LOCALE_DIR)
gettext.textdomain('goldendog-welcome')
_ = gettext.gettext

class GoldenDogWelcomeWindow(Adw.ApplicationWindow):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)

        self.set_title(_("Welcome to GoldenDog Linux"))
        # Set fixed size to prevent the issue of seeing multiple slides when maximized
        # and to match the "small, centered" look of gnome-welcome.
        # User requested expansion to fix "sloppy" cramping and overlap issues.
        self.set_default_size(850, 650)
        self.set_resizable(False)

        # Toast Overlay
        # Adw.ApplicationWindow doesn't have add_toast in some versions, or usage requires overlay
        self.toast_overlay = Adw.ToastOverlay()
        self.set_content(self.toast_overlay)

        # Main content box
        self.main_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
        # self.set_content(self.main_box) -> Moved to be child of overlay
        self.toast_overlay.set_child(self.main_box)

        # Header Bar - remove window controls if we want it to look like a strict dialog?
        # Standard Adwaita apps usually keep them. We'll keep them but the window is fixed size.
        self.header_bar = Adw.HeaderBar()
        self.header_bar.add_css_class("flat") # cleaner look
        self.main_box.append(self.header_bar)

        # Content Area - Horizontal box to hold [Prev] [Carousel] [Next]
        self.content_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=12)
        self.content_box.set_hexpand(True)
        self.content_box.set_vexpand(True)
        self.main_box.append(self.content_box)

        # Previous Button
        self.prev_btn = Gtk.Button()
        self.prev_btn.add_css_class("flat")
        self.prev_btn.set_valign(Gtk.Align.CENTER)
        self.prev_btn.set_margin_start(8)
        
        # Load custom prev icon
        prev_icon_path = os.path.join(os.path.dirname(__file__), "..", "assets", "go-previous.svg")
        if os.path.exists(prev_icon_path):
            img = Gtk.Image.new_from_file(prev_icon_path)
            # Make arrows larger (approx 2x standard)
            img.set_pixel_size(48)
            self.prev_btn.set_child(img)
        else:
            self.prev_btn.set_icon_name("go-previous-symbolic")
            
        self.prev_btn.connect("clicked", self._on_prev_clicked)
        self.content_box.append(self.prev_btn)

        # Carousel
        self.carousel = Adw.Carousel()
        self.carousel.set_hexpand(True)
        self.carousel.set_vexpand(True)
        self.carousel.connect("page-changed", self._on_page_changed)
        self.content_box.append(self.carousel)
        
        # Next Button
        self.next_btn = Gtk.Button()
        self.next_btn.add_css_class("flat")
        self.next_btn.set_valign(Gtk.Align.CENTER)
        self.next_btn.set_margin_end(8)
        
        # Load custom next icon
        next_icon_path = os.path.join(os.path.dirname(__file__), "..", "assets", "go-next.svg")
        if os.path.exists(next_icon_path):
            img = Gtk.Image.new_from_file(next_icon_path)
            # Make arrows larger (approx 2x standard)
            img.set_pixel_size(48)
            self.next_btn.set_child(img)
        else:
            self.next_btn.set_icon_name("go-next-symbolic")

        self.next_btn.connect("clicked", self._on_next_clicked)
        self.content_box.append(self.next_btn)

        # --- SLIDES ---
        self._build_welcome_slide()
        self._build_eula_slide()
        self._build_telemetry_slide()
        self._build_newsletter_slide()
        self._build_finish_slide()

        # Carousel Indicator - dots at the bottom
        self.dots = Adw.CarouselIndicatorDots()
        self.dots.set_carousel(self.carousel)
        self.dots.set_margin_bottom(16)
        self.main_box.append(self.dots)
        
        # Initial button state update
        self._on_page_changed(self.carousel, 0)

    def _build_welcome_slide(self):
        page = Adw.StatusPage()
        page.set_title(_("Welcome to GoldenDog Linux"))
        page.set_description(_("Thank you for choosing GoldenDog. Let's get you set up."))
        # Force the page to fill the carousel area so we don't see neighbors
        page.set_hexpand(True)
        page.set_vexpand(True)
        
        # Load custom icon
        # We use a Gtk.Picture for the custom image as the 'child' of the status page
        # This renders below the description, which looks fine and is reliable.
        # Load custom icon
        # We use a Gtk.Picture for the custom image as the 'child' of the status page
        icon_path = os.path.join(os.path.dirname(__file__), "..", "assets", "gdl-icon.svg")
        
        if os.path.exists(icon_path):
            # Using Gtk.Picture is often better for scalable graphics than Gtk.Image
            texture = Gdk.Texture.new_from_filename(icon_path)
            page.set_paintable(texture)
        else:
            page.set_icon_name("start-here-symbolic")
            
        self.carousel.append(page)

    def _build_eula_slide(self):
        page = Adw.StatusPage()
        page.set_title(_("License Agreement"))
        page.set_description(_("Please review and accept the terms to proceed."))
        # Icon removed to make more room for content
        # Force layout fill
        page.set_hexpand(True)
        page.set_vexpand(True)

        # Clamp for better layout
        clamp = Adw.Clamp()
        clamp.set_maximum_size(600)
        
        # Box for content
        box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=12)
        clamp.set_child(box)

        # Scrolled Window for EULA text
        scrolled = Gtk.ScrolledWindow()
        scrolled.set_min_content_height(350)
        scrolled.set_vexpand(True)
        
        # Frame for visual containment
        frame = Gtk.Frame()
        frame.set_child(scrolled)
        box.append(frame)
        
        # Load license text
        license_path = os.path.join(os.path.dirname(__file__), "..", "assets", "agpl-3.0.txt")
        license_content = _("AGPL v3 License text could not be loaded.")
        if os.path.exists(license_path):
            try:
                with open(license_path, 'r', encoding='utf-8') as f:
                    license_content = f.read()
            except Exception as e:
                print(f"Error reading license: {e}")
        
        eula_text = Gtk.Label(label=license_content)
        eula_text.set_wrap(True)
        eula_text.set_selectable(True)
        eula_text.set_margin_top(12)
        eula_text.set_margin_bottom(12)
        eula_text.set_margin_start(12)
        eula_text.set_margin_end(12)
        # Use monospace for license text
        eula_text.add_css_class("monospace")
        scrolled.set_child(eula_text)

        # Checkbox
        self.eula_check = Gtk.CheckButton(label=_("I accept the terms of the license"))
        self.eula_check.set_halign(Gtk.Align.CENTER)
        self.eula_check.set_margin_top(12)
        box.append(self.eula_check)

        page.set_child(clamp)
        self.carousel.append(page)

    def _build_newsletter_slide(self):
        page = Adw.StatusPage()
        page.set_title(_("Stay Informed"))
        page.set_description(_("Subscribe to our newsletters to receive the latest news and security updates."))
        
        page.set_hexpand(True)
        page.set_vexpand(True)
        
        clamp = Adw.Clamp()
        clamp.set_maximum_size(600)
        
        box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=12)
        clamp.set_child(box)
        
        # Email Entry Group
        email_group = Adw.PreferencesGroup()
        box.append(email_group)
        
        self.email_entry = Adw.EntryRow()
        self.email_entry.set_title(_("Email Address"))
        self.email_entry.set_input_purpose(Gtk.InputPurpose.EMAIL)
        email_group.add(self.email_entry)
        
        # Newsletter Lists Group
        lists_group = Adw.PreferencesGroup()
        lists_group.set_title(_("Available Newsletters"))
        box.append(lists_group)
        
        # News List
        self.news_switch = Gtk.Switch()
        self.news_switch.set_active(False)
        self.news_switch.set_valign(Gtk.Align.CENTER)
        news_row = Adw.ActionRow()
        news_row.set_title(_("General News"))
        news_row.set_subtitle(_("Monthly updates about the project and community."))
        news_row.add_suffix(self.news_switch)
        lists_group.add(news_row)
        
        # Security List
        self.security_switch = Gtk.Switch()
        self.security_switch.set_active(False)
        self.security_switch.set_valign(Gtk.Align.CENTER)
        security_row = Adw.ActionRow()
        security_row.set_title(_("Security Updates"))
        security_row.set_subtitle(_("Urgent alerts about vulnerabilities and patches."))
        security_row.add_suffix(self.security_switch)
        lists_group.add(security_row)
        
        # Subscribe Button
        self.subscribe_btn = Gtk.Button(label=_("Subscribe"))
        self.subscribe_btn.add_css_class("pill")
        self.subscribe_btn.add_css_class("suggested-action")
        self.subscribe_btn.set_halign(Gtk.Align.CENTER)
        self.subscribe_btn.set_margin_top(12)
        self.subscribe_btn.connect("clicked", self._on_subscribe_clicked)
        box.append(self.subscribe_btn)
        
        page.set_child(clamp)
        self.carousel.append(page)

    def _on_subscribe_clicked(self, button):
        email = self.email_entry.get_text().strip()
        if not email or "@" not in email:
            toast = Adw.Toast.new(_("Please enter a valid email address."))
            self.toast_overlay.add_toast(toast)
            return
            
        news_enabled = self.news_switch.get_active()
        security_enabled = self.security_switch.get_active()
        
        if not news_enabled and not security_enabled:
            toast = Adw.Toast.new(_("Please select at least one newsletter."))
            self.toast_overlay.add_toast(toast)
            return

        # Disable UI during request
        self.subscribe_btn.set_sensitive(False)
        self.email_entry.set_sensitive(False)
        self.news_switch.set_sensitive(False)
        self.security_switch.set_sensitive(False)
        
        # Start subscription in a thread to avoid blocking UI
        thread = threading.Thread(target=self._do_subscribe, args=(email, news_enabled, security_enabled))
        thread.start()

    def _do_subscribe(self, email, news, security):
        # UUIDs
        UUIDS_EN = {
            "news": "90163d3c-64bb-4910-aa3e-dd71e0944cf6",
            "security": "57977cb6-60a6-465b-98f0-0b626847ed0d"
        }
        UUIDS_ES = {
            "news": "fadf16f3-eaa3-4549-9f34-8aa3af8d45c2",
            "security": "8a189f90-84b7-4f2c-8784-49509c895c54"
        }
        
        # Language detection
        # Check LANGUAGE env var first (used by gettext), then fall back to locale
        is_spanish = False
        try:
            # First check LANGUAGE environment variable (what gettext uses)
            language_env = os.environ.get('LANGUAGE', '')
            if language_env.startswith('es'):
                is_spanish = True
            else:
                # Fall back to locale detection
                try:
                    lang = locale.getlocale()[0]
                    if lang and lang.startswith('es'):
                        is_spanish = True
                except:
                    pass
        except:
            pass
            
        uuids_source = UUIDS_ES if is_spanish else UUIDS_EN
        selected_uuids = []
        if news: selected_uuids.append(uuids_source["news"])
        if security: selected_uuids.append(uuids_source["security"])
        
        payload = {
            "email": email,
            "name": "",
            "list_uuids": selected_uuids,
            "confirm": True
        }
        
        try:
            req = urllib.request.Request(
                "https://lists.goldendoglinux.org/api/public/subscription",
                data=json.dumps(payload).encode('utf-8'),
                headers={'Content-Type': 'application/json'},
                method='POST'
            )
            with urllib.request.urlopen(req, timeout=10) as response:
                if response.status == 200:
                    # Success
                    from gi.repository import GLib
                    GLib.idle_add(self._on_subscribe_success)
                else:
                    from gi.repository import GLib
                    GLib.idle_add(self._on_subscribe_error, _("Server returned an error."))
        except Exception as e:
            from gi.repository import GLib
            GLib.idle_add(self._on_subscribe_error, str(e))

    def _on_subscribe_success(self):
        self.subscribe_btn.set_label(_("Subscribed!"))
        self.subscribe_btn.remove_css_class("suggested-action")
        self.subscribe_btn.add_css_class("success")
        toast = Adw.Toast.new(_("Subscription successful! Please check your email to confirm."))
        self.toast_overlay.add_toast(toast)
        # We don't re-enable the UI to prevent multiple subs

    def _on_subscribe_error(self, error_msg):
        self.subscribe_btn.set_sensitive(True)
        self.email_entry.set_sensitive(True)
        self.news_switch.set_sensitive(True)
        self.security_switch.set_sensitive(True)
        toast = Adw.Toast.new(_("Error: ") + error_msg)
        self.toast_overlay.add_toast(toast)

    def _build_telemetry_slide(self):
        page = Adw.StatusPage()
        page.set_title(_("Data & Privacy"))
        page.set_description(_("Choose how you want to contribute."))
        
        # Custom Icon: candado.svg
        icon_path = os.path.join(os.path.dirname(__file__), "..", "assets", "candado.svg")
        if os.path.exists(icon_path):
            texture = Gdk.Texture.new_from_filename(icon_path)
            page.set_paintable(texture)
        else:
            page.set_icon_name("preferences-system-privacy-symbolic")
            
        # Force layout fill
        page.set_hexpand(True)
        page.set_vexpand(True)
        
        # Clamp the content width - increased for better readability
        clamp = Adw.Clamp()
        clamp.set_maximum_size(600)
        
        # Preferences Group
        # We can add a description to the group for more context
        group = Adw.PreferencesGroup()
        group.set_description(_("Your privacy is important. No personal data is collected."))
        clamp.set_child(group)
        
        # Plasma Telemetry
        plasma_row = Adw.ActionRow()
        plasma_row.set_title(_("KDE Plasma Telemetry"))
        plasma_row.set_subtitle(_("Send anonymous usage data to KDE to help improve the desktop experience."))
        self.plasma_switch = Gtk.Switch()
        self.plasma_switch.set_active(False)
        self.plasma_switch.set_valign(Gtk.Align.CENTER)
        plasma_row.add_suffix(self.plasma_switch)
        group.add(plasma_row)
        
        # Debian Telemetry
        debian_row = Adw.ActionRow()
        debian_row.set_title(_("Debian Popularity Contest"))
        debian_row.set_subtitle(_("Submit anonymous package usage statistics to help Debian decide what to include."))
        self.debian_switch = Gtk.Switch()
        self.debian_switch.set_active(False)
        self.debian_switch.set_valign(Gtk.Align.CENTER)
        debian_row.add_suffix(self.debian_switch)
        group.add(debian_row)
        
        page.set_child(clamp)
        self.carousel.append(page)

    def _build_finish_slide(self):
        page = Adw.StatusPage()
        page.set_title(_("You're All Set!"))
        page.set_description(_("Review your choices and start using your system."))
        
        # Custom Icon: gdl-icon.svg (repeating the welcome icon)
        icon_path = os.path.join(os.path.dirname(__file__), "..", "assets", "gdl-icon.svg")
        if os.path.exists(icon_path):
            texture = Gdk.Texture.new_from_filename(icon_path)
            page.set_paintable(texture)
        else:
            page.set_icon_name("emblem-ok-symbolic")
            
        # Force layout fill
        page.set_hexpand(True)
        page.set_vexpand(True)
        
        btn = Gtk.Button(label=_("Start Using GoldenDog"))
        btn.add_css_class("pill")
        btn.add_css_class("suggested-action")
        btn.set_halign(Gtk.Align.CENTER)
        btn.set_margin_top(24)
        btn.connect("clicked", self._on_finish_clicked)
        
        # We append the button to the page content
        # Adw.StatusPage has a 'child' property
        page.set_child(btn)
        
        self.carousel.append(page)

    def _on_finish_clicked(self, button):
        # Validation
        if not self.eula_check.get_active():
            # Show error or toast
            toast = Adw.Toast.new(_("You must accept the license agreement to proceed."))
            self.toast_overlay.add_toast(toast)
            # Scroll back to EULA page (index 1)
            self.carousel.scroll_to(self.carousel.get_nth_page(1), True)
            return

        # Get telemetry states
        # We need to access the switches. I'll need to store references to them in _build_telemetry_slide
        plasma = self.plasma_switch.get_active()
        debian = self.debian_switch.get_active()

        from config import save_preferences
        if save_preferences(True, plasma, debian):
            print("Settings saved.")
            self.close()
        else:
            toast = Adw.Toast.new(_("Error saving settings."))
            self.toast_overlay.add_toast(toast)

    def _on_prev_clicked(self, button):
        idx = self.carousel.get_position()
        if idx > 0:
            self.carousel.scroll_to(self.carousel.get_nth_page(idx - 1), True)

    def _on_next_clicked(self, button):
        idx = self.carousel.get_position()
        n_pages = self.carousel.get_n_pages()
        if idx < n_pages - 1:
            self.carousel.scroll_to(self.carousel.get_nth_page(idx + 1), True)

    def _on_page_changed(self, carousel, index):
        # Update button states based on current page
        idx = carousel.get_position()
        n_pages = carousel.get_n_pages()
        
        # Simple sensitivity/visibility
        self.prev_btn.set_sensitive(idx > 0)
        
        # On last page, next button could be hidden or disabled since we have a big "Finish" button
        if idx >= n_pages - 1:
            self.next_btn.set_opacity(0)
            self.next_btn.set_sensitive(False)
        else:
            self.next_btn.set_opacity(1)
            self.next_btn.set_sensitive(True)
