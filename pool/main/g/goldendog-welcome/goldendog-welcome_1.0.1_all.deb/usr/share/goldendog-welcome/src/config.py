import os
import subprocess
import configparser

# Paths (can be overridden for testing)
CONFIG_DIR = os.path.expanduser("~/.config/goldendog-welcome")
EULA_MARKER = os.path.expanduser("~/.eula_agreed")

def save_preferences(eula_accepted, plasma_telemetry, debian_telemetry):
    """
    Save the user's preferences and apply settings.
    """
    if not eula_accepted:
        # Should not happen if UI is correct, but safety check
        return False

    # 1. Mark EULA as accepted
    try:
        with open(EULA_MARKER, 'w') as f:
            f.write("agreed\n")
    except IOError as e:
        print(f"Error saving EULA marker: {e}")

    # 2. Apply Plasma Telemetry
    # This usually involves writing to ~/.config/kuserfeedbackrc or running a command
    # For now, we'll mock the config write or use a placeholder
    _apply_plasma_telemetry(plasma_telemetry)

    # 3. Apply Debian Telemetry (popularity-contest)
    _apply_debian_telemetry(debian_telemetry)

    # 4. Disable this welcome app from running again
    disable_autostart()
    
    return True

def _apply_debian_telemetry(enabled):
    """
    Configure Debian Popularity Contest.
    Target: /etc/popularity-contest.conf
    Sets PARTICIPATE="yes" or "no"
    Requires Root privileges via pkexec.
    """
    conf_file = "/etc/popularity-contest.conf"
    
    # If the popularity‑contest config does not exist, the package is not installed.
    # In that case we simply skip applying Debian telemetry.
    if not os.path.exists(conf_file):
        print(f"Popularity contest config not found at {conf_file}, skipping Debian telemetry.")
        return

    val = "yes" if enabled else "no"
    
    # Use the helper script to modify the config file
    # Check production path first, then fall back to development path
    helper_path = "/usr/libexec/goldendog-welcome/set-popcon-participate"
    
    if not os.path.exists(helper_path):
        # Development fallback
        helper_path = os.path.join(os.path.dirname(__file__), "..", "helpers", "set-popcon-participate")
    
    if not os.path.exists(helper_path):
        print(f"Error: Helper script not found at {helper_path}")
        return
    
    cmd = ["pkexec", helper_path, val]
    
    print(f"Applying Debian Telemetry: {val}")
    try:
        subprocess.run(cmd, check=True)
    except subprocess.CalledProcessError as e:
        print(f"Failed to apply popularity-contest settings (user cancelled?): {e}")
    except FileNotFoundError:
         print("pkexec not found.")

def _apply_plasma_telemetry(enabled):
    """
    Configure KDE Plasma User Feedback.
    Target: ~/.config/PlasmaUserFeedback
    If enabled:
      [Global]
      FeedbackLevel=32
    If disabled:
      File is emptied (touched).
    """
    config_path = os.path.expanduser("~/.config/PlasmaUserFeedback")
    
    try:
        with open(config_path, 'w') as f:
            if enabled:
                f.write("[Global]\nFeedbackLevel=32\n")
            else:
                # Just open/close writes an empty file (truncates it)
                pass
        print(f"Plasma Telemetry applied: {'32 (Fair)' if enabled else 'Disabled'}")
    except IOError as e:
        print(f"Error writing Plasma telemetry config: {e}")

def disable_autostart():
    """
    Disable the autostart entry for this welcome screen.
    """
    autostart_dir = os.path.expanduser("~/.config/autostart")
    os.makedirs(autostart_dir, exist_ok=True)
    
    desktop_file = os.path.join(autostart_dir, "goldendog-welcome.desktop")
    # If we are running from a system location, we might copy the listener and add Hidden=true
    # Or just create a file that overrides the system one.
    
    content = """[Desktop Entry]
Type=Application
Name=GoldenDog Welcome
Hidden=true
"""
    try:
        with open(desktop_file, 'w') as f:
            f.write(content)
    except IOError as e:
        print(f"Failed to disable autostart: {e}")
